package com.cdac.entity_annotation;

public interface Course {
	void conductCourse();
}
