package com.cdac.entity;

public interface Trainer {
	void train();
}
