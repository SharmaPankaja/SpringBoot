package com.cdac.entity;

public class METNashik implements TrainingCenter {
	private Trainer javaTrainer;

	
	public METNashik() {
		System.out.println("Instantiation of TrainingCenter interface");
	}


	public Trainer getJavaTrainer() {
		return javaTrainer;
	}


	public void setJavaTrainer(Trainer javaTrainer) {
		this.javaTrainer = javaTrainer;
	}


	public METNashik(Trainer javaTrainer) {
		super();
		this.javaTrainer = javaTrainer;
	}


	@Override
	public void conductTraining() {
		System.out.println("Met Nashik is responsible to conduct training..");
		javaTrainer.train();
		
	}

}
