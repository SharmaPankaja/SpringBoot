package com.cdac.entity;

public interface Course {
	void conductCourse();
}
